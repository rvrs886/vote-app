package gl.rvrs.voteapp.users.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "voters")
public class Voter extends User {

	private Boolean blocked = false;

	public Voter(String username, String email, String password) {
		super(username, email, password);
	}

	public void block() {
		this.blocked = true;
	}

	public void unblock() {
		this.blocked = false;
	}

	public Boolean isBlocked() {
		return blocked;
	}
}
