package gl.rvrs.voteapp.users.controller;

import gl.rvrs.voteapp.users.domain.Voter;
import gl.rvrs.voteapp.users.domain.VoterView;
import gl.rvrs.voteapp.users.dto.VoterDto;
import gl.rvrs.voteapp.users.repo.VoterRepository;
import gl.rvrs.voteapp.users.service.VoterService;
import gl.rvrs.voteapp.util.ErrorDto;
import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;

import static org.springframework.http.HttpStatus.NOT_FOUND;

@RestController
@RequestMapping("/voters")
public class VoterController {

	private final VoterRepository voterRepository;
	private final VoterService voterService;

	public VoterController(VoterRepository voterRepository, VoterService voterService) {
		this.voterRepository = voterRepository;
		this.voterService = voterService;
	}

	@GetMapping
	public Page<VoterView> getAllVoters(Pageable pageable) {
		return voterRepository.findAll(pageable)
				.map(VoterView::from);
	}

	@GetMapping("/{id}")
	public VoterView getVoterById(@PathVariable Long id) {
		return VoterView.from(voterService.getVoter(id));
	}

	@PostMapping
	public VoterView saveVoter(@Valid  @RequestBody VoterDto voterDto) {
		Voter voter = voterService.createVoter(voterDto);
		return VoterView.from(voter);
	}

	@PutMapping("/{id}/block")
	public void blockVoter(@PathVariable Long id) {
		Voter voter = voterService.getVoter(id);
		voter.block();
		voterRepository.save(voter);
	}

	@PutMapping("/{id}/unblock")
	public void unblockVoter(@PathVariable Long id) {
		Voter voter = voterService.getVoter(id);
		voter.unblock();
		voterRepository.save(voter);
	}
}
