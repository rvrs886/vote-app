package gl.rvrs.voteapp.election.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;

import java.util.Set;

public record ElectionDto(@NotBlank String title, @NotBlank String description, @NotEmpty @Size(min = 2) Set<String> candidates) {
}
