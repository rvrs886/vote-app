package gl.rvrs.voteapp.election.repository;

import gl.rvrs.voteapp.election.domain.Vote;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VoteRepository extends JpaRepository<Vote, Long> {

}
